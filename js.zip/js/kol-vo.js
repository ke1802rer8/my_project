const minusBtn = document.querySelector('.js__item-counter__btn_minus');
const plusBtn = document.querySelector('.js__item-counter__btn_plus');
const valueBtn = document.querySelector('.js__item-counter__value');
console.log(valueBtn);