

    // menu 
    let menu = document.querySelector('.b24--select--catalog');
    let menuBtn = document.querySelector('.selectbox');

    
    $(function() {
        $('.selectbox').click(function() {
          $('.b24--select--catalog').slideToggle();
        });
      });
    

