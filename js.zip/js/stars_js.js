

    // menu 
    let grade = document.querySelector('.js__star_rating_btn');
    let click_stars = document.querySelector('.js__star_rating_star');

    popupRegistr.onclick = function(){
      login.style.display = "none";
      registr.style.display = "block";
    };
    
    

